#!/usr/bin/python

import feedparser

from urllib import urlopen

import os
import codecs

import sys
from getopt import getopt

from Queue import Queue
from threading import Thread

proxies = None
q = Queue()

def getURLName(url):
	directory=os.curdir

	name="%s%s%s" % (
		directory,
		os.sep,
		url.split("/")[-1]
	)

	return name

def createDownload(url, proxy=None):
	instream=urlopen(url, None, proxy)

	filename=instream.info().getheader("Content-Length")
	if filename==None:
		filename="temp"

	return (instream, filename)

def download(instream, outstream):
	outstream.write(instream.read())

	outstream.close()
	
def loader():
  while True:
    image = q.get()
    
    folder = image['folder']
    url = image['url']
    
    try:
      outfile = open(folder + '/' + getURLName(url), "wb")
      filename = outfile.name.split(os.sep)[-1]
  
      url, length = createDownload(url, proxies)
      if not length:
        length = "?"
    
      print "Downloading %s (%s bytes) ..." % (url.url, length)
      if length != "?":
        length = float(length)
    
        bytesRead = 0.0
    
        for line in url:
          bytesRead += len(line)
          outfile.write(line)
      
        url.close()
        outfile.close()
        print "Done"
  
    except Exception, e:
      print "Error downloading %s: %s" % (url, e)

def main():
  file = open("albums.list")
  try:
    for line in file:
      folder = line.strip()
    
      album = 'http://picasaweb.google.com/data/feed/back_compat/user/llunspace/albumid/' + folder + '?alt=rss&kind=photo&imgdl=1'
      images = feedparser.parse(album)
      
      if len(images.feed) == 0:
        continue
      
      os.mkdir(line.strip())
      
      title = images.feed.title
      titlefile = open(folder + '/title', 'w')
      titlefile.write(title)
      titlefile.close()
      
      for entry in images.entries:
        url = entry.pheed_imgsrc
        q.put({'folder': folder, 'url': url})
    
  finally:
    file.close()
    
  for i in range(5):
    t = Thread(target=loader)
    t.setDaemon(True)
    t.start()
    
  q.join()
    
if __name__ == "__main__":
  main()