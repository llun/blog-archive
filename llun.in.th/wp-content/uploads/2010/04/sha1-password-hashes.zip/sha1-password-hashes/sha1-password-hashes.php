<?php

/*
Plugin Name: SHA1 Password Hashes
Description: Extends from MD5 Password Hashes by changing encrypt algorithm to SHA1 for support Apache Authenticate via dbd
Author: llun
Author URI: http://llun.in.th
Version: 1.0

Version History:
1.0             : Initial Release
*/

if ( ! function_exists('wp_check_password') ):
function wp_check_password($password, $hash, $user_id = '') {
	// If the hash was updated to the new hash before this plugin
	// was installed, rehash as md5.
	if ( strlen($hash) != 56 ) {
		global $wp_hasher;
		if ( empty($wp_hasher) ) {
			require_once( ABSPATH . 'wp-includes/class-phpass.php');
			$wp_hasher = new PasswordHash(8, TRUE);
		}
		$check = $wp_hasher->CheckPassword($password, $hash);
		if ( $check && $user_id ) {
			// Rehash using new hash.
			wp_set_password($password, $user_id);
			$user = get_userdata($user_id);
			$hash = $user->user_pass;
		}

		return apply_filters('check_password', $check, $password, $hash, $user_id);
	}

	$check = ( $hash == base64_encode(sha1($password, true)) );

	return apply_filters('check_password', $check, $password, $hash, $user_id);
}
endif;

if ( !function_exists('wp_hash_password') ):
function wp_hash_password($password) {
	return base64_encode(sha1($password, true));
}
endif;

?>
