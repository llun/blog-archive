<?php
/*
Plugin Name: Facebook Like Plugin
Plugin URI: http://llun.in.th
Description: A simple plugin to display like button below post
Version: 1.0
Author: Maythee Anegboonlap
Author URI: http://llun.in.th
*/
add_filter('the_content', 'facebook_like');

function facebook_like($content) {
  $content .= '<div class="facebook-like">';
  $content .= '<iframe src="http://www.facebook.com/plugins/like.php?href=';
  $content .= urlencode(get_permalink(get_the_ID()));
  $content .= '&amp;layout=standard&amp;show_faces=true&amp;width=450&amp;action=like&amp;colorscheme=light" scrolling="no" frameborder="0" allowTransparency="true" style="border:none; overflow:hidden; width:450px; height:25px"></iframe>';
  $content .= '</div>';
  
	return $content;
}

?>