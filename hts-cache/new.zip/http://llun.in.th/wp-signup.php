<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>
<meta charset="UTF-8" />
<title>แนท (/næt/) | /īm/ /ə/ /prōgræmər/</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="robots" content="index, follow" />
<meta name="description" content="/īm/ /ə/ /prōgræmər/" />
<link rel="stylesheet" type="text/css" href="http://llun.in.th/wp-content/themes/canvas/style.css" media="all" />
<link rel="pingback" href="http://llun.in.th/xmlrpc.php" />
    <script type="text/javascript">
    // <![CDATA[
        var disqus_shortname = 'llun';
        (function () {
            var nodes = document.getElementsByTagName('span');
            for (var i = 0, url; i < nodes.length; i++) {
                if (nodes[i].className.indexOf('dsq-postid') != -1) {
                    nodes[i].parentNode.setAttribute('data-disqus-identifier', nodes[i].getAttribute('rel'));
                    url = nodes[i].parentNode.href.split('#', 1);
                    if (url.length == 1) { url = url[0]; }
                    else { url = url[1]; }
                    nodes[i].parentNode.href = url + '#disqus_thread';
                }
            }
            var s = document.createElement('script'); s.async = true;
            s.type = 'text/javascript';
                        s.src = 'http' + '://' + 'disqus.com/forums/' + disqus_shortname + '/count.js';
            (document.getElementsByTagName('HEAD')[0] || document.getElementsByTagName('BODY')[0]).appendChild(s);
        }());
    //]]>
    </script>
<meta property="og:description" content="Board game cafe" /><link rel="alternate" type="application/rss+xml" title="แนท (/næt/) &raquo; Feed" href="http://llun.in.th/feed/" />
<link rel="alternate" type="application/rss+xml" title="แนท (/næt/) &raquo; Comments Feed" href="http://llun.in.th/comments/feed/" />
<link rel='stylesheet' id='sharedaddy-css'  href='http://llun.in.th/wp-content/plugins/jetpack/modules/sharedaddy/sharing.css?ver=3.3.1' type='text/css' media='all' />
<script type='text/javascript' src='http://llun.in.th/wp-includes/js/jquery/jquery.js?ver=1.7.1'></script>
<script type='text/javascript' src='http://llun.in.th/wp-content/themes/canvas/includes/js/slides.min.jquery.js?ver=3.3.1'></script>
<script type='text/javascript' src='http://llun.in.th/wp-content/themes/canvas/includes/js/feedback.js?ver=3.3.1'></script>
<script type='text/javascript' src='http://llun.in.th/wp-content/themes/canvas/includes/js/general.js?ver=3.3.1'></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://llun.in.th/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://llun.in.th/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 3.3.1" />
<link rel='shortlink' href='http://wp.me/WUk2' />

<!-- ItsAbhik.com Facebook OpenGraph and Schema Microdata Generator Start -->
<meta property="og:title" content="แนท (/næt/)" />
<meta property="og:type" content="article" />
<meta property="og:url" content="http://llun.in.th" />
<meta property="og:image" content="" />
<meta property="og:site_name" content="แนท (/næt/)" />
<meta property="og:description" content="/īm/ /ə/ /prōgræmər/" />
<meta property="og:locale" content="en_US" />
<meta property="fb:admins" content="" />
<meta itemprop="name" content="แนท (/næt/)">
<meta itemprop="description" content="/īm/ /ə/ /prōgræmər/">
<meta itemprop="url" content="http://llun.in.th">
<!-- ItsAbhik.com Facebook OpenGraph and Schema Microdata Generator End -->

<!-- Twitter @Anywhere Plus v2.0 by GeekRMX - http://www.ngeeks.com -->
<script src="http://platform.twitter.com/anywhere.js?id=vWyrhNHf0VacEGLOdK13w&v=1" type="text/javascript"></script>
<script type="text/javascript">
twttr.anywhere(function (T) {
// configure the @anywhere environment
T.linkifyUsers();
T.hovercards();
});
</script>
<!-- /Twitter @Anywhere Plus -->

<!-- Theme version -->
<meta name="generator" content="Canvas 4.7.4" />
<meta name="generator" content="WooFramework 5.0.3" />

<!-- Woo Custom Styling -->
<style type="text/css">
#logo .site-title, #logo .site-description { display:block; }
body {background-color:#ccf3ff;background-repeat:no-repeat;background-position:top center;border-top:2px solid #000000;}
#header {background-repeat:no-repeat;background-position:top center;margin-top:0px;margin-bottom:0px;border:0px solid ;}
#logo .site-title a {font:normal 40px/1em Georgia, serif;color:#222222;}
#logo .site-description {font:italic 14px/1em Georgia, serif;color:#999999;}
#wrapper {padding-left:20px; padding-right:20px;background-color:#ffffff;border-top:2px solid #dbdbdb;border-bottom:2px solid #dbdbdb;border-left:2px solid #dbdbdb;border-right:2px solid #dbdbdb;border-radius:20px;-moz-border-radius:20px;-webkit-border-radius:20px;box-shadow: 0px 1px 5px rgba(0,0,0,.3);-moz-box-shadow: 0px 1px 5px rgba(0,0,0,.3);-webkit-box-shadow: 0px 1px 5px rgba(0,0,0,.3);}
body, p { font:normal 14px/1.5em Arial, sans-serif;color:#555555; }
h1 { font:normal 28px/1.5em Georgia, serif;color:#222222; }h2 { font:normal 24px/1.5em Georgia, serif;color:#222222; }h3 { font:normal 20px/1.5em Georgia, serif;color:#222222; }h4 { font:normal 16px/1.5em Georgia, serif;color:#222222; }h5 { font:normal 14px/1.5em Georgia, serif;color:#222222; }h6 { font:normal 12px/1.5em Georgia, serif;color:#222222; }
.post .title, .page .title, .post .title a:link, .post .title a:visited, .page .title a:link, .page .title a:visited {font:bold 24px/1.2em Arial, sans-serif;color:#222222;}
.post-meta { font:normal 11px/1.5em 'PT Serif', arial, sans-serif;color:#868686; }
.entry, .entry p{ font:normal 16px/1.5em 'PT Serif', arial, sans-serif;color:#555555; }
.post-more {font:normal 12px/1.5em Arial, sans-serif;color:#868686;border-top:4px solid #e6e6e6;border-bottom:1px solid #e6e6e6;}
#post-author, #connect {border-top:1px solid #e6e6e6;border-bottom:4px solid #e6e6e6;background-color:#fafafa}
.nav-entries, .wp-pagenavi, .woo-pagination {border-top:1px solid #e6e6e6;border-bottom:4px solid #e6e6e6; padding: 12px 0px; }
.nav-entries a, .wp-pagenavi a:link, .wp-pagenavi a:visited, .wp-pagenavi .current, .wp-pagenavi .on, .wp-pagenavi a:hover, .wp-pagenavi span.extend, .wp-pagenavi span.pages, .woo-pagination { font:italic 12px/1em 'PT Serif', arial, sans-serif;color:#777777; }
.wp-pagenavi a:link, .wp-pagenavi a:visited, .woo-pagination a, .woo-pagination a:hover, .wp-pagenavi span.extend, .wp-pagenavi span.pages, .wp-pagenavi span.current {color:#777777!important}
.widget h3 {font:bold 14px/1.5em PT Serif;color:#555555;border-bottom:3px solid #e6e6e6;}
.widget_recent_comments li, #twitter li { border-color: #e6e6e6;}
.widget p, .widget .textwidget { font:normal 12px/1.5em Arial, sans-serif;color:#555555; }
.widget {font:normal 12px/1.5em Arial, sans-serif;color:#555555;border-radius:0px;-moz-border-radius:0px;-webkit-border-radius:0px;}
#tabs .inside li a { font:bold 12px/1.5em 'PT Serif', arial, sans-serif;color:#555555; }
#tabs .inside li span.meta, #tabs ul.wooTabs li a { font:normal 11px/1.5em "Trebuchet MS", Tahoma, sans-serif;color:#777777; }
.nav a, #navigation ul.rss a { font:normal 14px/1em Arial, sans-serif;color:#555555; }
#navigation {border-top:1px solid #dbdbdb;border-bottom:4px solid #dbdbdb;border-left:0px solid #dbdbdb;border-right:0px solid #dbdbdb;border-radius:0px; -moz-border-radius:0px; -webkit-border-radius:0px;}
#top .nav a { font:normal 14px/1em Arial, sans-serif;color:#ddd; }
#footer, #footer p { font:italic 14px/1em 'PT Serif', arial, sans-serif;color:#777777; }
#footer {border-top:4px solid #dbdbdb;border-bottom:0px solid ;border-left:0px solid ;border-right:0px solid ;border-radius:0px; -moz-border-radius:0px; -webkit-border-radius:0px;}
.magazine #loopedSlider .content h2.title a { font:bold 24px/1em Arial, sans-serif;color:#ffffff; }
.magazine #loopedSlider .content .excerpt p { font:normal 12px/1.5em Arial, sans-serif;color:#cccccc; }
.business #loopedSlider .content h2.title a { font:bold 24px/1em Arial, sans-serif;color:#ffffff; }
.business #loopedSlider .content p { font:normal 12px/1.5em Arial, sans-serif;color:#cccccc; }
.archive_header { font:normal 18px/1em Arial, sans-serif;color:#555555;border-bottom:5px solid #e6e6e6;}
</style>
<!-- /Woo Custom Styling -->


<!-- Google Webfonts -->
<link href="http://fonts.googleapis.com/css?family=PT+Serif:r,b,i,bi" rel="stylesheet" type="text/css" />

<meta name='robots' content='noindex,nofollow' />
	<style type="text/css">
		.mu_register { width: 90%; margin:0 auto; }
		.mu_register form { margin-top: 2em; }
		.mu_register .error { font-weight:700; padding:10px; color:#333333; background:#FFEBE8; border:1px solid #CC0000; }
		.mu_register input[type="submit"],
			.mu_register #blog_title,
			.mu_register #user_email,
			.mu_register #blogname,
			.mu_register #user_name { width:100%; font-size: 24px; margin:5px 0; }
		.mu_register .prefix_address,
			.mu_register .suffix_address {font-size: 18px;display:inline; }
		.mu_register label { font-weight:700; font-size:15px; display:block; margin:10px 0; }
		.mu_register label.checkbox { display:inline; }
		.mu_register .mu_alert { font-weight:700; padding:10px; color:#333333; background:#ffffe0; border:1px solid #e6db55; }
	</style>
	<meta id="syntaxhighlighteranchor" name="syntaxhighlighter-version" content="3.1.3" />
<!-- Woo Shortcodes CSS -->
<link href="http://llun.in.th/wp-content/themes/canvas/functions/css/shortcodes.css" rel="stylesheet" type="text/css" />

<!-- Custom Stylesheet -->
<link href="http://llun.in.th/wp-content/themes/canvas/custom.css" rel="stylesheet" type="text/css" />
</head>
<body class="home blog unknown two-col-left width-940 two-col-left-940">
<div id="wrapper">        
	    
	<div id="header" class="col-full">
 		
		       
		<div id="logo">
		<h1 class="site-title"><a href="http://llun.in.th/">แนท (/næt/)</a></h1>
<span class="site-description">/īm/ /ə/ /prōgræmər/</span>
		</div><!-- /#logo -->
	       
		       
	</div><!-- /#header -->
		<div id="navigation" class="col-full">
				<ul id="main-nav" class="nav fl"><li id="menu-item-2593" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item menu-item-home menu-item-2593"><a href="http://llun.in.th/">/hoʊm/</a></li>
<li id="menu-item-2592" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2592"><a href="http://en.llun.in.th">/ˈɪŋ(ɡ)lɪʃ/</a></li>
<li id="menu-item-2144" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2144"><a href="http://llun.in.th/gallery/">/gæləri:/</a></li>
<li id="menu-item-2145" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2145"><a href="http://game.llun.in.th">/geim/</a></li>
<li id="menu-item-2142" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2142"><a href="http://llun.in.th/library/">/ˈlʌɪbrəri/</a></li>
<li id="menu-item-2143" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2143"><a href="http://llun.in.th/want/">/wɔnt/</a></li>
</ul>	
	</div><!-- /#navigation -->

<div id="content" class="widecolumn">
<div class="mu_register">
Registration has been disabled.</div>
</div>

	<div id="footer" class="col-full">
	
		    
	    
		<div id="copyright" class="col-left">
			<p>&copy; 2012 แนท (/næt/). All Rights Reserved. </p>		</div>
		
		<div id="credit" class="col-right">
			<p>Powered by <a href="http://wordpress.org/" title="WordPress">WordPress</a>. Designed by <a href="http://www.woothemes.com/" title="WooThemes"><img src="http://llun.in.th/wp-content/themes/canvas/images/woothemes.png" width="74" height="19" alt="Woo Themes" /></a></p>		</div>
		
	</div><!-- /#footer  -->
	
	    
	
	</div><!-- /#wrapper -->
	
	<div class="fix"></div><!--/.fix-->
	
	<script type='text/javascript' src='http://s.gravatar.com/js/gprofiles.js?aa&#038;ver=3.3.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var WPGroHo = {"my_hash":""};
/* ]]> */
</script>
<script type='text/javascript' src='http://llun.in.th/wp-content/plugins/jetpack/modules/wpgroho.js?ver=3.3.1'></script>
	<div style="display:none">
	</div>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-6918582-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
		</body>
</html>